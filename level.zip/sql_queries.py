import sqlite3
conn = sqlite3.connect("Artistc.db")
cursor = conn.cursor()
cursor.execute("SELECT * FROM artists")
data = cursor.fetchall()
#print(data)


# Вопрос 1. Информация о скольких художниках представлена в базе данных? 
cursor.execute("SELECT * FROM artists")
data = cursor.fetchall()
print(len(data))

# Вопрос 2. Сколько женщин (Female) в базе?
cursor.execute("SELECT * FROM artists WHERE Gender == 'Female'")
data1 = cursor.fetchall()
print(len(data1))
# Вопрос 3. Сколько человек в базе данных родились до 1900 года?
cursor.execute("SELECT * FROM artists WHERE 'Birth Year' < 1900 ")
data2 = cursor.fetchall()
print(data2)

# Вопрос 4*. Как зовут самого пожилого художника?
cursor.execute("SELECT * FROM artists ")
startup = dict()


data3 = cursor.fetchall()
for i in data3:
    print(i)
    #year = 'Birth Year' < 1830 and 'Birth Year' >= 1800
